﻿using DP_Strategy.Interfaces;
using DP_Strategy.Models;
using System;

namespace DP_Strategy // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var produto = new Produto()
            {
                Codigo = 1,
                Nome = "Cadeira",
                Tipo = "A",
                ValorProduto = 100
            };

            StrategyContextCalcularPreco contextPreco = new StrategyContextCalcularPreco();
            contextPreco.setUpdateStrategy(new StrategyCalcularPrecoTipoA(produto));
            Console.WriteLine(contextPreco.getPrecoFinal()) ;


            contextPreco.setUpdateStrategy(new StrategyCalcularPrecoTipoB(produto));
            Console.WriteLine(contextPreco.getPrecoFinal());
        }
    }
}