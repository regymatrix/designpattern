using DP_Strategy.Interfaces;
using DP_Strategy.Models;
using Xunit;

namespace DP_Test
{
    public class ProutoTest
    {

        [Fact]
        public void PrecoProdutoFinalTipoAIgual110()
        {

            var produto = new Produto()
            {
                Codigo = 1,
                Nome = "Cadeira",
                Tipo = "A",
                ValorProduto = 100
            };

            double esperado = 110.00;

            StrategyContextCalcularPreco context = new StrategyContextCalcularPreco();
            context.setUpdateStrategy(new StrategyCalcularPrecoTipoA(produto));

            var resultado = context.getPrecoFinal();

            Assert.Equal(esperado, resultado);
         

        }

        [Fact]
        public void PrecoProdutoFinalTipoARecebeNulleRetorna0()
        {

            var produto = new Produto()
            {
                Codigo = 1,
                Nome = "Cadeira",
                Tipo = "A",
                ValorProduto = null
            };

            double esperado =0;

            StrategyContextCalcularPreco context = new StrategyContextCalcularPreco();
            context.setUpdateStrategy(new StrategyCalcularPrecoTipoA(produto));

            var resultado = context.getPrecoFinal();

            Assert.Equal(esperado, resultado);


        }
    }
}